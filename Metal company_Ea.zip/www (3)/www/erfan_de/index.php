<html>
<head>
   <title>Muhammad Yunus</title>
   <link rel="stylesheet" href="style.css">
   </head>
   <body>
   <!--This is top bar-->
      <div id="top"><P>Top bar</p></div>
<!--this is header area-->
<div><?php include("includes/header.php");   ?></div>
   
   
    <div><?php include("includes/nav.php");   ?></div>
  <div><?php include("includes/sidebar.php");   ?></div>
  <div><?php include("includes/post_body.php");   ?></div>
  
  
   
   
   <div class="foot">This is footer</div>
   

   
   
   
   
   
   
   </body>
   <html>