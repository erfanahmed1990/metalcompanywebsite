<?php
 $link = mysqli_connect("localhost","root","pappo","malala");

?> 