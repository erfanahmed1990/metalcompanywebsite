   <div class="navbar">
	  <div id="menu">
	  <ul>
	      <li><a href="index.php">Home</a></li>
		  <li><a href="#">Younus News</a></li>
		  <li><a href="#">Younus Grameen bank</a></li>
		  <li><a href="#">Younus Photos</a></li>
		  <li><a href="#">About us</a></li>
		  <li><a href="#">Mission</a></li>
		  <li><a href="#">Contact Us</a></li>
	  </ul>
	  </div>
	  </div>